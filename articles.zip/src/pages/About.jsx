function About() {
  return (
    <div>
      <h1>About</h1>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit quidem
        laudantium quasi recusandae soluta earum consequatur, aliquid aut
        impedit voluptates alias ea saepe reiciendis expedita neque ab illum
        aspernatur similique dolore dicta enim nam minus! Incidunt facere nemo
        neque consectetur, delectus tenetur corporis officiis eum suscipit nisi
        quisquam, dolores perspiciatis?
      </p>
    </div>
  );
}

export default About;
